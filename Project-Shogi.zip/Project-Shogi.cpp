#include<iostream>
#include<conio.h>
#include<iomanip>
#include<Windows.h>
#include<fstream>
#define rows 85
#define cols 117
using namespace std;
enum COL { w, b };
void getRowColbyLeftClick(int& rpos, int& cpos)
{
	HANDLE hInput = GetStdHandle(STD_INPUT_HANDLE);
	DWORD Events;
	INPUT_RECORD InputRecord;
	SetConsoleMode(hInput, ENABLE_PROCESSED_INPUT | ENABLE_MOUSE_INPUT | ENABLE_EXTENDED_FLAGS);
	do
	{
		ReadConsoleInput(hInput, &InputRecord, 1, &Events);
		if (InputRecord.Event.MouseEvent.dwButtonState == FROM_LEFT_1ST_BUTTON_PRESSED)
		{
			cpos = InputRecord.Event.MouseEvent.dwMousePosition.X;
			rpos = InputRecord.Event.MouseEvent.dwMousePosition.Y;
			break;
		}
	} while (true);
}
void gotoRowCol(int rpos, int cpos)
{
	COORD scrn;
	HANDLE hOuput = GetStdHandle(STD_OUTPUT_HANDLE);
	scrn.X = cpos;
	scrn.Y = rpos;
	SetConsoleCursorPosition(hOuput, scrn);
}
void SetClr(int clr)
{
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), clr);
}
struct position
{
	int ri, ci;
};
void U(int cr, int cc, int scale, char sym = -37)
{
	SetClr(13);
	int r = cr, c = cc;

	r = r + scale / 2;
	c = cc;
	for (int i = 1; i <= scale / 2; i++) {
		gotoRowCol(r, c);
		cout << sym;
		c++;
	}
	c = cc;
	for (int i = 1; i <= scale / 2; i++) {
		gotoRowCol(r, c);
		cout << sym;
		c--;
	}
	c = cc - scale / 2 + 1;
	r = cr;
	for (int i = 0; i < scale / 2; i++) {
		gotoRowCol(r, c);
		cout << sym;
		r++;
	}
	for (int i = 0; i <= scale; i++) {
		gotoRowCol(r, c);
		cout << sym;
		r--;
	}

	c = cc + scale / 2 - 1;
	r = cr;
	for (int i = 0; i < scale / 2; i++) {
		gotoRowCol(r, c);
		cout << sym;
		r++;
	}
	for (int i = 0; i <= scale; i++) {
		gotoRowCol(r, c);
		cout << sym;
		r--;
	}


}
void R(int cr, int cc, int scale, char sym = -37)
{

	SetClr(13);
	int r = cr, c = cc;


	c = cc - scale / 2 + 1;
	r = cr;
	for (int i = 0; i < scale / 2; i++) {
		gotoRowCol(r, c);
		cout << sym;
		r++;
	}
	for (int i = 0; i <= scale; i++) {
		gotoRowCol(r, c);
		cout << sym;
		r--;
	}

	r = cr, c = cc + 2;
	for (int i = 0; i <= scale / 2; i++)
	{
		gotoRowCol(r, c);
		cout << sym;
		r--; c--;
	}
	r = cr, c = cc + 2;
	for (int i = 0; i <= scale / 2; i++)
	{
		gotoRowCol(r, c);
		cout << sym;
		r++; c--;
	}


}
void D(int cr, int cc, int scale, char sym = -37)
{
	SetClr(13);
	int r = cr, c = cc;
	r = r - scale / 2;
	c = cc;
	for (int i = 1; i <= scale / 2; i++) {
		gotoRowCol(r, c);
		cout << sym;
		c++;
	}
	c = cc;
	for (int i = 1; i <= scale / 2; i++) {
		gotoRowCol(r, c);
		cout << sym;
		c--;
	}
	r = cr;

	r = r + scale / 2;
	c = cc;
	for (int i = 1; i <= scale / 2; i++) {
		gotoRowCol(r, c);
		cout << sym;
		c++;
	}
	c = cc;
	for (int i = 1; i <= scale / 2; i++) {
		gotoRowCol(r, c);
		cout << sym;
		c--;
	}
	c = cc - scale / 2 + 1;
	r = cr;
	for (int i = 0; i < scale / 2; i++) {
		gotoRowCol(r, c);
		cout << sym;
		r++;
	}
	for (int i = 0; i < scale; i++) {
		gotoRowCol(r, c);
		cout << sym;
		r--;
	}

	c = cc + scale / 2 - 1;
	r = cr;
	for (int i = 0; i < scale / 2; i++) {
		gotoRowCol(r, c);
		cout << sym;
		r++;
	}
	for (int i = 0; i < scale; i++) {
		gotoRowCol(r, c);
		cout << sym;
		r--;
	}


}

bool choice_RL(position S, position D)
{
	if (S.ri > D.ri && S.ci > D.ci)
	{
		return true;
	}
	if (S.ri < D.ri && S.ci < D.ci)
	{
		return true;
	}
	return false;
}
bool cap(char a)
{
	if (a >= 65 && a <= 90)
	{
		return true;
	}
	return false;
}
void kng(int r, int c)
{


	gotoRowCol(r + 2, c + 1);
	cout << char(-37);
	gotoRowCol(r + 2, c + 4);
	cout << char(-37);
	gotoRowCol(r + 2, c + 7);
	cout << char(-37);

	for (int i = 1; i < 8; i++)
	{
		gotoRowCol(r + 3, c + i);
		cout << char(-37);
	}

	for (int i = 2; i < 7; i++)
	{
		gotoRowCol(r + 4, c + i);
		cout << char(-37);
	}

	for (int i = 3; i < 6; i++)
	{
		gotoRowCol(r + 5, c + i);
		cout << char(-37);
	}
	for (int i = 2; i < 7; i++)
	{
		gotoRowCol(r + 6, c + i);
		cout << char(-37);
	}
	for (int i = 1; i < 8; i++)
	{
		gotoRowCol(r + 7, c + i);
		cout << char(-37);
	}
}
void pwn(int r, int c)
{
	gotoRowCol(r + 3, c + 4);
	cout << char(-37);
	for (int i = 2; i < 7; i++)
	{
		gotoRowCol(r + 4, c + i);
		cout << char(-37);
	}

	for (int i = 3; i < 6; i++)
	{
		gotoRowCol(r + 5, c + i);
		cout << char(-37);
	}

	for (int i = 1; i < 8; i++)
	{
		gotoRowCol(r + 6, c + i);
		cout << char(-37);
	}





}
void sgen(int r, int c)
{

	gotoRowCol(r + 2, c + 4);
	cout << char(-37);


	for (int i = 1; i < 8; i++)
	{
		gotoRowCol(r + 3, c + i);
		cout << char(-37);
	}

	for (int i = 2; i < 7; i++)
	{
		gotoRowCol(r + 4, c + i);
		cout << char(-37);
	}

	for (int i = 3; i < 6; i++)
	{
		gotoRowCol(r + 5, c + i);
		cout << char(-37);
	}
	for (int i = 2; i < 7; i++)
	{
		gotoRowCol(r + 6, c + i);
		cout << char(-37);
	}
	for (int i = 1; i < 8; i++)
	{
		gotoRowCol(r + 7, c + i);
		cout << char(-37);
	}

}
void ggen(int r, int c)
{
	gotoRowCol(r + 2, c + 1);
	cout << char(-37);

	gotoRowCol(r + 2, c + 7);
	cout << char(-37);

	for (int i = 1; i < 8; i++)
	{
		gotoRowCol(r + 3, c + i);
		cout << char(-37);
	}

	for (int i = 2; i < 7; i++)
	{
		gotoRowCol(r + 4, c + i);
		cout << char(-37);
	}

	for (int i = 3; i < 6; i++)
	{
		gotoRowCol(r + 5, c + i);
		cout << char(-37);
	}
	for (int i = 2; i < 7; i++)
	{
		gotoRowCol(r + 6, c + i);
		cout << char(-37);
	}
	for (int i = 1; i < 8; i++)
	{
		gotoRowCol(r + 7, c + i);
		cout << char(-37);
	}

}
void lnce(int r, int c)
{

	for (int i = 1; i < 8; i++)
	{
		gotoRowCol(r + 3, c + i);
		cout << char(-37);

	}
	for (int j = 0; j < 2; j++) {

		for (int i = 3; i < 6; i++)
		{
			gotoRowCol(r + 4 + j, c + i);
			cout << char(-37);
		}
	}


	for (int i = 2; i < 7; i++)
	{
		gotoRowCol(r + 6, c + i);
		cout << char(-37);

	}
	for (int i = 1; i < 8; i++)
	{
		gotoRowCol(r + 7, c + i);
		cout << char(-37);

	}


}
void rouk(int r, int c)
{

	gotoRowCol(r + 2, c + 4);
	cout << char(-37);
	for (int i = 1; i < 8; i++)
	{
		gotoRowCol(r + 3, c + i);
		cout << char(-37);
	}
	for (int i = 2; i < 7; i++)
	{
		gotoRowCol(r + 4, c + i);
		cout << char(-37);
	}
	for (int i = 3; i < 6; i++)
	{
		gotoRowCol(r + 5, c + i);
		cout << char(-37);
	}
	for (int i = 4; i < 5; i++)
	{
		gotoRowCol(r + 6, c + i);
		cout << char(-37);
	}


	for (int i = 1; i < 8; i++)
	{
		gotoRowCol(r + 7, c + i);
		cout << char(-37);
	}

}
void nite(int r, int c)
{

	for (int i = 4; i < 6; i++)
	{
		gotoRowCol(r + 1, c + i); cout << char(-37);
	}

	for (int i = 2; i < 7; i++)
	{
		gotoRowCol(r + 2, c + i); cout << char(-37);
	}

	for (int i = 1; i < 3; i++)
	{
		gotoRowCol(r + 3, c + i); cout << char(-37);
	}

	for (int i = 5; i < 8; i++)
	{
		gotoRowCol(r + 3, c + i); cout << char(-37);
	}
	for (int i = 5; i < 7; i++)
	{
		gotoRowCol(r + 4, c + i); cout << char(-37);
	}
	for (int i = 4; i < 6; i++)
	{
		gotoRowCol(r + 5, c + i); cout << char(-37);
	}

	gotoRowCol(r + 6, c + 4); cout << char(-37);

	for (int i = 1; i < 8; i++)
	{
		gotoRowCol(r + 7, c + i);
		cout << char(-37);
	}



}
void bishp(int r, int c)
{
	gotoRowCol(r + 2, c + 4);
	cout << char(-37);
	for (int i = 2; i < 7; i++)
	{
		gotoRowCol(r + 3, c + i);
		cout << char(-37);
	}
	for (int i = 4; i < 6; i++)
	{
		gotoRowCol(r + i, c + 4);
		cout << char(-37);
	}
	for (int i = 3; i < 6; i++)
	{
		gotoRowCol(r + 6, c + i);
		cout << char(-37);
	}
	for (int i = 1; i < 8; i++)
	{
		gotoRowCol(r + 7, c + i);
		cout << char(-37);
	}

}
void printshp(int r, int c, char ch)
{
	if (cap(ch))
	{
		SetClr(0);
	}
	if (cap(ch) && (ch == 'E' || ch == 'W' || ch == 'Q' || ch == 'U' || ch == 'T' || ch == 'Y'))
	{
		SetClr(3);
	}
	if ((!cap(ch)) && (ch == 'e' || ch == 'w' || ch == 'q' || ch == 'u' || ch == 't' || ch == 'y'))
	{
		SetClr(11);
	}
	if (!cap(ch)) {
		SetClr(15);

	}
	if (ch == 'k' || ch == 'K')
	{

		kng(r, c);
	}
	if (ch == 'l' || ch == 'L' || ch == 'e' || ch == 'E')
	{
		lnce(r, c);
	}
	if (ch == 'p' || ch == 'P' || ch == 'w' || ch == 'W')
	{
		pwn(r, c);
	}
	if (ch == 's' || ch == 'S' || ch == 'q' || ch == 'Q')
	{
		sgen(r, c);
	}

	if (ch == 'r' || ch == 'R' || ch == 'y' || ch == 'Y')
	{
		rouk(r, c);
	}
	if (ch == 'n' || ch == 'N' || ch == 't' || ch == 'T')
	{
		nite(r, c);
	}
	if (ch == 'b' || ch == 'B' || ch == 'u' || ch == 'U')
	{
		bishp(r, c);
	}
	if (ch == 'g' || ch == 'G')
	{
		ggen(r, c);
	}
}


bool isH(position Sc, position Dc)
{
	return(Sc.ri == Dc.ri);


}
bool isV(position Sc, position Dc)
{
	return(Sc.ci == Dc.ci);


}
bool isD(position Sc, position Dc)
{
	int dr = abs(Sc.ri - Dc.ri);
	int ds = abs(Sc.ci - Dc.ci);
	return(dr == ds);

}
bool isHClr(char** B, position Sc, position Dc)
{
	if (Sc.ci < Dc.ci)
	{
		for (int c = Sc.ci; c < Dc.ci; c++)
		{
			if (B[Sc.ri][c] != '-');
			{
				return false;
			}
		}
		return true;
	}
	else
	{
		for (int c = Dc.ci; c < Sc.ci; c++)
		{
			if (B[Sc.ri][c] != '-');
			{
				return false;
			}
		}
		return true;
	}
}
bool isVClr(char** B, position Sc, position Dc)
{
	if (Sc.ri < Dc.ri)
	{
		for (int c = Sc.ri; c < Dc.ri; c++)
		{
			if (B[c][Sc.ci] != '-');
			{
				return false;
			}
		}
		return true;
	}
	else
	{
		for (int c = Dc.ri; c < Sc.ri; c++)
		{
			if (B[c][Sc.ci] != '-');
			{
				return false;
			}
		}
		return true;
	}
}
bool isHClr2(char** B, position Sc, position Dc)
{
	int cs, ce;
	if (Sc.ci < Dc.ci)
	{
		cs = Sc.ci + 1, ce = Dc.ci - 1;
	}
	else
	{
		cs = Dc.ci + 1, ce = Sc.ci - 1;
	}
	for (int c = cs; c <= ce; c++)
	{
		if (B[Sc.ri][c] != '-')
		{
			return false;
		}
	}
	return true;
}
bool isVClr2(char** B, position Sc, position Dc)
{
	int rs, re;
	if (Sc.ri < Dc.ri)
	{
		rs = Sc.ri + 1, re = Dc.ri - 1;
	}
	else
	{
		rs = Dc.ri + 1, re = Sc.ri - 1;
	}
	for (int r = rs; r <= re; r++)
	{
		if (B[r][Sc.ci] != '-')
		{
			return false;
		}
	}
	return true;
}
bool isD1clr(char** B, position S, position D)
{
	if (S.ri < D.ri)
	{
		int dr = D.ri - S.ri - 1;
		for (int i = 1; dr >= i; i++)
		{
			if (B[S.ri + i][S.ci + i] != '-')
				return false;
		}
		return true;
	}
	else
	{
		int dr = S.ri - D.ri - 1;
		for (int i = 1; dr >= i; i++)
		{
			if (B[S.ri - i][S.ci - i] != '-')
				return false;
		}
		return true;
	}



}
bool isD2clr(char** B, position S, position D)
{
	if (S.ri < D.ri)
	{
		int dr = abs(D.ri - S.ri - 1);
		for (int i = 1; dr >= i; i++)
		{
			if (B[S.ri + i][S.ci - i] != '-')
				return false;
		}
		return true;
	}
	else
	{
		int dr = abs(S.ri - D.ri - 1);
		for (int i = 1; dr >= i; i++)
		{
			if (B[S.ri - i][S.ci + i] != '-')
				return false;
		}
		return true;
	}


}
bool Pthclr(char** b, position sc, position dc)
{
	if (isH(sc, dc))
	{
		return(isHClr(b, sc, dc));

	}
	if (isV(sc, dc))
	{
		return(isVClr(b, sc, dc));
	}
	if (isD(sc, dc))
	{
		int dr = (sc.ri - dc.ri);
		int ds = (sc.ci - dc.ci);
		if (dr == ds)
		{
			return(isD1clr(b, sc, dc));
		}
		else
		{
			return(isD2clr(b, sc, dc));
		}
	}
}

void init(char**& b, char**& bl, char**& wh, int& dim, string pname[], int& turn, const string a)
{
	ifstream rdr(a);
	rdr >> dim;
	rdr >> turn;
	b = new char* [dim];
	bl = new char* [dim];
	wh = new char* [dim];

	for (int i = 0; i < dim; i++)
	{
		b[i] = new char[dim];
		bl[i] = new char[dim];
		wh[i] = new char[dim];

	}

	for (int i = 0; i < dim; i++)
	{
		for (int j = 0; j < dim; j++)
		{
			rdr >> b[i][j];
		}
	}
	for (int i = 0; i < 2; i++)
	{
		for (int j = 0; j < 10; j++)
		{
			rdr >> bl[i][j];
		}
	}
	for (int i = 0; i < 2; i++)
	{
		for (int j = 0; j < 10; j++)
		{
			rdr >> wh[i][j];
		}
	}

}
void spos(position& p)
{
	cout << "Give coordinate(A1:H8): ";
	int d;
	char c;
	cin >> c >> d;
	c = toupper(c);
	p.ci = c - 'A';
	p.ri = d - 1;

}
void spos1(position& p)
{
	cout << "Give coordinate(A1:H8): ";
	int c1, c2;

	getRowColbyLeftClick(c2, c1);
	p.ci = c1 / 9;
	p.ri = c2 / 9;

}

void printboard(char** b, int dim)
{
	for (int i = 0; i < dim; i++)
	{
		for (int j = 0; j < dim; j++)
		{
			cout << b[i][j] << " ";
		}
		cout << endl;
	}

}
void box(int sr, int sc, int brow, int bcol, int col)
{

	for (int r = 0; r < brow; r++)
	{
		for (int c = 0; c < bcol; c++)
		{

			SetClr(col);
			gotoRowCol(r + sr, c + sc);
			cout << char(-37);
		}
	}
}
void printg(char** b, int dr = 9, int dc = 9, int m = 0, int n = 0)
{
	int brow = 9, bcol = 9;
	for (int r = 0; r < dr; r++)
	{

		for (int c = 0; c < dc; c++)
		{

			if ((r + c) % 2 == 0)
			{
				box((r + m) * brow, (c + n) * bcol, brow, bcol, 7);
				printshp((r + m) * brow, (c + n) * bcol, b[r][c]);
			}
			else
			{
				box((r + m) * brow, (c + n) * bcol, brow, bcol, 8);
				printshp((r + m) * brow, (c + n) * bcol, b[r][c]);
			}
		}
	}


}
void printgg(char** b, position rr, position cc, int dr = 9, int dc = 9, int m = 0, int n = 0)
{
	int brow = 9, bcol = 9;
	for (int r = 0; r < dr; r++)
	{


		for (int c = 0; c < dc; c++)
		{
			if ((rr.ri == r && rr.ci == c) || (cc.ri == r && cc.ci == c)) {
				if ((r + c) % 2 == 0)
				{
					box((r + m) * brow, (c + n) * bcol, brow, bcol, 7);
					printshp((r + m) * brow, (c + n) * bcol, b[r][c]);
				}
				else
				{
					box((r + m) * brow, (c + n) * bcol, brow, bcol, 8);
					printshp((r + m) * brow, (c + n) * bcol, b[r][c]);
				}
			}
		}
	}


}
bool ismypice(char sym, int t)
{
	if (t == b && sym >= 'a' && sym <= 'z')
	{
		return true;
	}
	if (t == w && sym >= 'A' && sym <= 'Z')
	{
		return true;
	}
	return false;
}
bool isvalidd(char** b, position dc, int dim, int t)
{
	if (dc.ci >= dim || dc.ci < 0 || dc.ri >= dim || dc.ri < 0)
	{
		return false;
	}
	return (!ismypice(b[dc.ri][dc.ci], t) || b[dc.ri][dc.ci] == '-');
}
bool isvaliddd(char** b, position dc, int dim, int t)
{
	if (dc.ci >= dim || dc.ci < 0 || dc.ri >= dim || dc.ri < 0)
	{
		return false;
	}
	return (b[dc.ri][dc.ci] == '-');
}
bool isvalids(char** b, position sc, int dim, int t)
{
	if (sc.ci >= dim || sc.ci < 0 || sc.ri >= dim || sc.ri < 0)
	{
		return false;
	}
	return ismypice(b[sc.ri][sc.ci], t);
}
position finddash(char** a)
{
	position cr;
	for (int i = 0; i < 2; i++)
	{
		for (int j = 0; j < 10; j++)
		{
			if (a[i][j] == '-')
			{
				cr.ri = i;
				cr.ci = j;
				return cr;
			}


		}

	}
}
void updatebrd(char** b, position dc, position sc)
{

	b[dc.ri][dc.ci] = ' '; char p = b[sc.ri][sc.ci];
	b[dc.ri][dc.ci] = p;
	b[sc.ri][sc.ci] = '-';
}
void turnch(int& t)
{
	t = (t + 1) % 2;

}

bool bishop(char** b, position sc, position dc)
{

	if (isD(sc, dc))
	{
		if (choice_RL(sc, dc))
		{
			if (isD1clr(b, sc, dc))
				return true;
		}
		else if (isD2clr(b, sc, dc))
			return true;
	}
	return false;

}

bool rook(char** B, position Sc, position Dc)
{
	return ((isH(Sc, Dc) && isHClr2(B, Sc, Dc)) || (isV(Sc, Dc) && isVClr2(B, Sc, Dc)));


}

bool pawn(char** b, position sc, position dc)
{
	int d = abs(sc.ri - dc.ri);
	if (b[sc.ri][sc.ci] == 'p')
	{
		return(isV(sc, dc) && (sc.ri > dc.ri) && d == 1);
	}
	else
	{
		return(isV(sc, dc) && (sc.ri < dc.ri) && d == 1);
	}
}
bool king(char** b, position sc, position dc)
{
	int d = abs(sc.ri - dc.ri);
	int d1 = abs(sc.ci - dc.ci);
	if (isH(sc, dc))
	{
		return(d1 == 1);
	}
	if (isV(sc, dc))
	{
		return(d == 1);
	}
	if (isD(sc, dc))
	{
		return(d == 1 && d1 == 1);
	}

}
bool gold(char** B, position Sc, position Dc)
{
	int dr = abs(Sc.ri - Dc.ri);
	int dc = abs(Sc.ci - Dc.ci);
	if (B[Sc.ri][Sc.ci] == 'g')
	{
		return dr <= 1 && dc <= 1 && (rook(B, Sc, Dc) || ((Sc.ri > Dc.ri) && bishop(B, Sc, Dc)));
	}
	else
	{
		return dr <= 1 && dc <= 1 && (rook(B, Sc, Dc) || ((Sc.ri < Dc.ri) && bishop(B, Sc, Dc)));
	}


}
bool silver(char** B, position Sc, position Dc)
{
	int dr = abs(Sc.ri - Dc.ri);
	int dc = abs(Sc.ci - Dc.ci);
	return(dr <= 1 && dc <= 1 && (pawn(B, Sc, Dc) || bishop(B, Sc, Dc)));

}

bool knite(char** b, position sc, position dc)
{
	int dr = abs(sc.ri - dc.ri);
	int dcl = abs(sc.ci - dc.ci);
	if (b[sc.ri][sc.ci] == 'n')
	{
		return (dr == 2 && dcl == 1 && sc.ri > dc.ri);
	}
	else {
		return (dr == 2 && dcl == 1 && sc.ri < dc.ri);
	}
}
bool lance(char** b, position sc, position dc)
{
	if (b[sc.ri][sc.ci] == 'l')
	{
		return(isV(sc, dc) && (sc.ri > dc.ri) && rook(b, sc, dc));
	}
	else
	{
		return(isV(sc, dc) && (sc.ri < dc.ri) && rook(b, sc, dc));
	}
}
bool legalmove(char** b, position sc, position dc, int d, int t)
{
	switch (b[sc.ri][sc.ci])
	{
	case'r':
	case 'R':
		return(rook(b, sc, dc));
		break;
	case'p':
	case 'P':
		return(pawn(b, sc, dc));
		break;
	case'l':
	case 'L':
		return(lance(b, sc, dc));
		break;
	case'k':
	case 'K':
		return(king(b, sc, dc));
		break;
	case'b':
	case 'B':
		return(bishop(b, sc, dc));
		break;
	case'g':
	case 'G':
		return(gold(b, sc, dc));
		break;
	case'w':
	case 'W':
		return(gold(b, sc, dc));
		break;
	case'e':
	case 'E':
		return(gold(b, sc, dc));
		break;
	case'q':
	case 'Q':
		return(gold(b, sc, dc));
		break;
	case't':
	case 'T':
		return(gold(b, sc, dc));
		break;

	case's':
	case 'S':
		return(silver(b, sc, dc));
		break;
	case'n':
	case 'N':
		return(knite(b, sc, dc));
		break;

	case'u':
	case'U':
		return(king(b, sc, dc) || bishop(b, sc, dc));
		break;
	case'y':
	case'Y':
		return(king(b, sc, dc) || rook(b, sc, dc));
		break;
	}





	return true;
}

void printdaba(int r, int c, int d, int cl = 4)
{
	for (int i = 0; i < d; i++)
	{
		for (int j = 0; j < d; j++)
		{
			if (i == 0 || j == 0 || i == d - 1 || j == d - 1) {
				gotoRowCol(i + r, j + c);
				SetClr(cl);
				cout << char(-37);
			}
		}
	}
}
void dohighlight(bool** m, int dim)
{
	for (int i = 0; i < dim; i++)
	{
		for (int j = 0; j < dim; j++)
		{
			if (m[i][j])
			{
				printdaba(i * dim, j * dim, dim);
			}
		}
	}
}
void dounhighlight(bool** m, int dim)
{
	for (int i = 0; i < dim; i++)
	{
		for (int j = 0; j < dim; j++)
		{
			if (m[i][j])
			{
				if ((i + j) % 2 == 0)
				{
					printdaba(i * dim, j * dim, dim, 7);
				}
				else {
					printdaba(i * dim, j * dim, dim, 8);
				}
			}
		}
	}
}
position findking(char** b, int d, int t)
{
	position king;
	for (int i = 0; i < d; i++)
	{
		for (int j = 0; j < d; j++)
		{
			if (t == 1 && b[i][j] == 'k')
			{
				king.ri = i;
				king.ci = j;
				return king;
			}
			if (t == 0 && b[i][j] == 'K')
			{
				king.ri = i;
				king.ci = j;
				return king;
			}

		}
	}
}
struct redo
{
	char** br;
	char** bl;
	char** wh;

};
bool check(char** b, int d, int t)
{
	turnch(t);
	position dc = findking(b, d, t);
	position sc;
	turnch(t);
	for (int i = 0; i < d; i++)
	{
		for (int j = 0; j < d; j++)
		{
			sc.ri = i; sc.ci = j;
			if (legalmove(b, sc, dc, d, t) && isvalids(b, sc, d, t))
			{
				return true;
			}
		}
	}

	return false;
}
bool selfcheck(char** b, int d, int t)
{
	turnch(t);
	return(check(b, d, t));


}
void copy(char** a, char**& b, int d = 9, int dd = 9)
{

	b = new char* [dd];
	for (int i = 0; i < dd; i++)
	{
		b[i] = new char[d];
	}

	for (int i = 0; i < dd; i++)
	{
		for (int j = 0; j < d; j++)
		{
			b[i][j] = a[i][j];
		}
	}
}

bool** highlight(char** b, position sc, int d, int t)
{
	bool** bm = new bool* [d];
	for (int i = 0; i < d; i++)
	{
		bm[i] = new bool[d] {};
	}
	position dc;
	for (int i = 0; i < d; i++)
	{
		for (int j = 0; j < d; j++)
		{
			dc.ri = i;
			dc.ci = j;
			if (isvalidd(b, dc, d, t) && legalmove(b, sc, dc, d, t))
			{
				bm[i][j] = true;
			}
		}
	}


	return bm;
}
void promcheck(char**& b, position dc)
{
	if (cap(b[dc.ri][dc.ci]) && dc.ri >= 6)
	{
		if (b[dc.ri][dc.ci] == 'L')
		{
			b[dc.ri][dc.ci] = 'E';
		}
		if (b[dc.ri][dc.ci] == 'P')
		{
			b[dc.ri][dc.ci] = 'W';
		}
		if (b[dc.ri][dc.ci] == 'S')
		{
			b[dc.ri][dc.ci] = 'Q';
		}
		if (b[dc.ri][dc.ci] == 'N')
		{
			b[dc.ri][dc.ci] = 'T';
		}
		if (b[dc.ri][dc.ci] == 'R')
		{
			b[dc.ri][dc.ci] = 'Y';
		}
		if (b[dc.ri][dc.ci] == 'B')
		{
			b[dc.ri][dc.ci] = 'U';
		}

	}
	if (!cap(b[dc.ri][dc.ci]) && dc.ri <= 2)
	{
		if (b[dc.ri][dc.ci] == 'l')
		{
			b[dc.ri][dc.ci] = 'e';
		}
		if (b[dc.ri][dc.ci] == 'p')
		{
			b[dc.ri][dc.ci] = 'w';
		}
		if (b[dc.ri][dc.ci] == 's')
		{
			b[dc.ri][dc.ci] = 'q';
		}
		if (b[dc.ri][dc.ci] == 'n')
		{
			b[dc.ri][dc.ci] = 't';
		}
		if (b[dc.ri][dc.ci] == 'r')
		{
			b[dc.ri][dc.ci] = 'y';
		}
		if (b[dc.ri][dc.ci] == 'b')
		{
			b[dc.ri][dc.ci] = 'u';
		}
	}
}
void save(char** b, int d, int t, char** bl, char** wh)
{
	ofstream w("Text1.txt");
	w << d << endl;
	w << t << endl;
	for (int i = 0; i < d; i++)
	{
		for (int j = 0; j < d; j++)
		{
			w << b[i][j];
		}
		w << endl;
	}
	for (int i = 0; i < 2; i++)
	{
		for (int j = 0; j < 10; j++)
		{
			w << bl[i][j];
		}
		w << endl;
	}
	for (int i = 0; i < 2; i++)
	{
		for (int j = 0; j < 10; j++)
		{
			w << wh[i][j];
		}
		w << endl;
	}



}

void drop(char** b, position dc, char** bl, char** wh)
{
	position cr;
	if (b[dc.ri][dc.ci] != '-') {

		if (cap(b[dc.ri][dc.ci]))
		{
			cr = finddash(bl);
			if (b[dc.ri][dc.ci] == 'W')
			{
				bl[cr.ri][cr.ci] = 'P';
			}
			if (b[dc.ri][dc.ci] == 'E')
			{
				bl[cr.ri][cr.ci] = 'L';
			}
			if (b[dc.ri][dc.ci] == 'Q')
			{
				bl[cr.ri][cr.ci] = 'S';
			}
			if (b[dc.ri][dc.ci] == 'Y')
			{
				bl[cr.ri][cr.ci] = 'R';
			}
			if (b[dc.ri][dc.ci] == 'T')
			{
				bl[cr.ri][cr.ci] = 'N';
			}
			if (b[dc.ri][dc.ci] == 'U')
			{
				bl[cr.ri][cr.ci] = 'B';
			}
			//if(b[dc.ri][dc.ci] == 'K'|| b[dc.ri][dc.ci] == 'G')
			//{
			//	bl[cr.ri][cr.ci] = b[dc.ri][dc.ci];
			//}
			else
			{
				bl[cr.ri][cr.ci] = b[dc.ri][dc.ci];
			}


		}
		if (!cap(b[dc.ri][dc.ci])) {
			cr = finddash(wh);
			if (b[dc.ri][dc.ci] == 'w')
			{
				wh[cr.ri][cr.ci] = 'p';
			}
			if (b[dc.ri][dc.ci] == 'e')
			{
				wh[cr.ri][cr.ci] = 'l';
			}
			if (b[dc.ri][dc.ci] == 'q')
			{
				wh[cr.ri][cr.ci] = 's';
			}
			if (b[dc.ri][dc.ci] == 'y')
			{
				wh[cr.ri][cr.ci] = 'r';
			}
			if (b[dc.ri][dc.ci] == 't')
			{
				wh[cr.ri][cr.ci] = 'n';
			}
			if (b[dc.ri][dc.ci] == 'u')
			{
				wh[cr.ri][cr.ci] = 'b';
			}
			else
			{
				wh[cr.ri][cr.ci] = b[dc.ri][dc.ci];
			}

		}
	}

}
void printdrops(char** a, char** b)
{
	gotoRowCol(10, 85);
	SetClr(12);
	cout << "Blacks killed one\n";
	for (int i = 0; i < 2; i++)
	{
		for (int j = 0; j < 10; j++)
		{
			gotoRowCol(11 + i, 85 + j);
			cout << a[i][j] << " ";
		}
		cout << endl;
	}
	gotoRowCol(30, 85);
	cout << "Whites killed one\n";
	for (int i = 0; i < 2; i++)
	{
		for (int j = 0; j < 10; j++)
		{
			gotoRowCol(31 + i, 85 + j);
			cout << b[i][j] << " ";
		}
		cout << endl;
	}

}
void printbtn()
{
	printdaba(0, 82, 7, 1);
	U(3, 85, 4);
	R(3, 93, 4);
	printdaba(0, 90, 7, 1);
	printdaba(0, 98, 7, 1);
	D(3, 101, 4);
}
bool valids(char** w, char** b, int t, position sc)
{
	return true;
	position wc; position bc;
	wc = finddash(w);


	if (t == 1)
	{
		if (bc.ri);




	}
	else {




	}


}

void selectcordwh(position& sc)
{
	position c;
	getRowColbyLeftClick(c.ri, c.ci);
	sc.ri = (c.ri / 9) - 4;
	sc.ci = (c.ci / 9) - 10;

}
void selectcordbl(position& sc)
{
	position c;
	getRowColbyLeftClick(c.ri, c.ci);
	sc.ri = (c.ri / 9) - 1;
	sc.ci = (c.ci / 9) - 10;
}
void selectcord(position& sc, int t)
{
	if (t == 1)
	{
		selectcordbl(sc);
	}
	if (t == 0)
	{
		selectcordwh(sc);
	}

}
void replay(redo arr[], int t)
{
	for (int i = 0; i < t; i++)
	{
		printg(arr[i].br, 9);
		position wc, bc;
		wc = finddash(arr[i].wh);
		bc = finddash(arr[i].bl);
		int t = 0, chk = 0;
		printg(arr[i].bl, bc.ri, bc.ci, 1, 10);
		printg(arr[i].wh, wc.ri, wc.ci, 4, 10);
		Sleep(1000);
	}
}


void updbrd(char** a, char** b, char** c, position sc, position dc, int t)
{
	if (t == 1) {
		char p = b[sc.ri][sc.ci];
		b[sc.ri][sc.ci] = '-';
		a[dc.ri][dc.ci] = p;

	}
	if (t == 0) {
		char p = c[sc.ri][sc.ci];
		c[sc.ri][sc.ci] = '-';
		a[dc.ri][dc.ci] = p;

	}


}
bool checkmate(char** b, int turn, int dim = 9)
{


	turnch(turn);
	char** nq;
	bool** M;
	position s;
	position d;
	for (int i = 0; i < dim; i++) {
		for (int j = 0; j < dim; j++) {
			s.ri = i;
			s.ci = j;
			if (isvalids(b, s, dim, turn)) {
				M = highlight(b, s, dim, turn);
				for (int m = 0; m < dim; m++) {
					for (int n = 0; n < dim; n++) {
						copy(b, nq, dim);
						if (M[m][n]) {
							d.ri = m;
							d.ci = n;
							updatebrd(nq, d, s);
							if (!selfcheck(nq, dim, turn))
								return false;
						}
					}
				}
			}
		}
	}
	return true;



}

void shogi()
{
	int dim, turn;
	char** b; string pname[2];
	bool** h;
	char** nq;
	redo undu[1000];
	cout << "To Load Press 1\nTo Restart Press 2";
	int x; string aa;
	cin >> x;
	if (x == 1)
	{
		aa = "load.txt";
	}
	if (x == 2)
	{
		aa = "new.txt";
	}


	char** bl;
	char** wh;
	init(b, bl, wh, dim, pname, turn, aa);


	position sc, dc;
	position wc, bc;
	wc = finddash(wh);
	bc = finddash(bl);
	int t = 0, chk = 0;
	printg(b, dim, dim);
	//printdrops(bl, wh);
	printg(bl, bc.ri, bc.ci, 1, 10);
	printg(wh, wc.ri, wc.ci, 4, 10);
	while (true)
	{


		chk = 0;
		save(b, dim, turn, bl, wh);
		copy(b, undu[t].br);
		copy(bl, undu[t].bl, 10, 2);
		copy(wh, undu[t].wh, 10, 2);
		printbtn();
		wc = finddash(wh);
		bc = finddash(bl);
		if (wc.ri == 1)
		{
			wc.ci = 10;
		}
		if (bc.ri == 1)
		{
			bc.ci = 10;
		}
		printg(bl, bc.ri + 1, bc.ci, 1, 10);
		printg(wh, wc.ri + 1, wc.ci, 4, 10);

		////////////////////////////////////////////////////
		int cr, cc;
		getRowColbyLeftClick(cr, cc);
		while (cr >= 0 && cr < 7 && cc >= 82 && cc < 89 && t >= 0)
		{
			wc = finddash(wh);
			bc = finddash(bl);

			copy(undu[t].br, b);
			copy(undu[t].bl, bl, 10, 2);
			copy(undu[t].wh, wh, 10, 2);

			printg(b, dim, dim);
			//printdrops(bl, wh);
			printg(bl, bc.ci, bc.ri, 1, 10);
			printg(wh, wc.ci, wc.ri, 4, 10);
			getRowColbyLeftClick(cr, cc);
			t--;
			turnch(turn);
		}
		if (cr >= 0 && cr < 7 && cc >= 90 && cc < 97)
		{
			replay(undu, t);
		}
		if (cr >= 0 && cr < 7 && cc >= 98 && cc < 105)
		{
			do {
				do {
					gotoRowCol(82, 0);
					cout << "\nSelectionnnnnnnnnnnn\n";
					selectcord(sc, turn);

				} while (!valids(wh, b, turn, sc));
				cout << "\ndestinationnnnnnnnnnnn\n";
				spos1(dc);
			} while (!isvaliddd(b, dc, dim, turn));
			updbrd(b, bl, wh, sc, dc, turn);


			chk = 1;
		}


		////////////////////////////////////////////////////
		if (chk == 0) {
			do {
				do
				{
					do
					{


						do
						{
							gotoRowCol(82, 0);
							cout << "\nSelection\n";
							spos1(sc);
						} while (!isvalids(b, sc, dim, turn));
						h = highlight(b, sc, dim, turn);
						dohighlight(h, dim);
						gotoRowCol(82, 0);
						cout << "\nDestination\n";
						spos1(dc);
						dounhighlight(h, dim);

					} while (!isvalidd(b, dc, dim, turn));

				} while (h[dc.ri][dc.ci] != 1);
				copy(b, nq);
				updatebrd(nq, dc, sc);
			} while (selfcheck(nq, dim, turn));

			drop(b, dc, bl, wh);
			updatebrd(b, dc, sc);
			promcheck(b, dc);
		}



		system("cls");
		if (check(b, dim, turn))
		{
			gotoRowCol(1, 107);
			SetClr(4);
			cout << "Check!";
		}
		printbtn();
		printg(b);
		//printgg(b,dc,sc);
		//printdrops(bl, wh);
		wc = finddash(wh);
		bc = finddash(bl);
		if (wc.ri == 1)
		{
			wc.ci = 10;
		}
		if (bc.ri == 1)
		{
			bc.ci = 10;
		}
		printg(bl, bc.ri + 1, bc.ci, 1, 10);
		printg(wh, wc.ri + 1, wc.ci, 4, 10);
		if (checkmate(b, turn))
		{
			system("cls");
			cout << "Checkmteeeeeee\n";
			break;
		}
		turnch(turn);

		t++;
	}
}


int main()
{
	
	shogi();

	return _getch();

}
